# BD-mex

# INSTALLATIONS
8
​

- `pkg update`
- `pkg upgrade`

- `pkg install python`

- `pkg install python`

- `pip install requests`

- `pip install mechanize`

- `pip install lolcat`

- `pip install bs4`

- `pkg install git`

- `rm -rf BD-mex`

# MAIN CAMMANDS



- `pip install rich`

- `git clone https://github.com/Shuvo-BBHH/BD-mex`

- `cd BD-mex`

- `python mahdi.py`


​
27
# PROVE
28
![211362395-09a9d311-06ee-4767-8f83-d57e4fec4200_LI (4)](https://user-images.githubusercontent.com/98658558/211752850-d3dd66c5-edc6-42e2-82cc-e98b1ddfd6d2.jpg)
29
