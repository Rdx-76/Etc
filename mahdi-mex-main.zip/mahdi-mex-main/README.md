# mahdi-mex

# PROGRAMMED BY MAHDI

 # version 5.7

# INSTALLATIONS

- `pkg update`
- `pkg upgrade`
- `pkg install python`
- `pkg install python`
- `pip install requests`
- `pip install mechanize`
- `pip install lolcat`
- `pip install bs4`
- `pkg install git`
- `rm -rf mahdi-mex`
# MAIN CAMMANDS

- `pip install rich`
- `git clone https://github.com/Shuvo-BBHH/mahdi-mex`
- `cd mahdi-mex`
- `python mahdi.py`


# PROVE
![211362395-09a9d311-06ee-4767-8f83-d57e4fec4200_LI (4)](https://user-images.githubusercontent.com/98658558/211752850-d3dd66c5-edc6-42e2-82cc-e98b1ddfd6d2.jpg)

