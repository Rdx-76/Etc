# Hrdenc
HEARD  ENCRIPTION
# Hrdenc

# PROGRAMMED BY MAHDI

# INSTALLATIONS

- `pkg update`
- `pkg upgrade`
- `pkg install python`
- `pkg install python`
- `pip install requests`
- `pip install mechanize`
- `pip install lolcat`
- `pip install bs4`
- `pkg install git`
- `rm -rf Hrdenc`
# MAIN CAMMANDS

- `pip install rich`
- `git clone https://github.com/Shuvo-BBHH/Hrdenc`
- `cd Hrdenc`
- `python mahdi.py`


# prove

![Screenshot (37)](https://user-images.githubusercontent.com/98658558/235291620-95a39b06-79fb-4814-a578-37e3f1d3375b.png)
