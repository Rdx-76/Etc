Before

# header 1

Paragraph with **bold** and *italic*
on
multiple
lines.

> Some citation

A footnote[^1] and this also[^note]

## header 2

```jq
code
block
```

    also
    code

### header 3

Some text with `code`

#### header 4

Some text [with a link](http://host/path)

An image ![img alt text](path/image.png)

##### header 5

- list of
- things

a table

| a   | b   | c   |
| --- | --- | --- |
| 1   | 2   | 3   |

###### header 6

Some text with line <br> break and <b>bold</b>

[^1]: footnote1
[^note]: footnote2
