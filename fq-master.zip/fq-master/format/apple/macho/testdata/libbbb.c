#include <stdio.h>

void libbbb_bbb()
{
    printf("libbbb_bbb\n");
}
