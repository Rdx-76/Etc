# MAFIA-XD



<b></b> </br> <br>[![Facebook](https://img.shields.io/badge/Facebook-MAFIA-blue?style=flat-square&logo=facebook)](https://www.facebook.com/muzamil.khan09)<br> [![Whatsapp](https://img.shields.io/badge/Whatsapp-MAFIA-deepgreen?style=flat-square&logo=whatsapp)](https://wa.me/+923091649663)

 

 

 

<h1 align="center"> [MAFIA-XD]</h1>

 

<h2 align="center">  FB CLONING TOOL </h2>

 

 

## <b>installation</b>

 

🔰 _CLONE FULL OK IDZ_

 

 

- `pkg update`

- `pkg upgrade`

- `pkg install git`

- `pkg install python`

- `pip install requests`

- `pip install mechanize`

- `rm -rf MAFIA`

- `git clone --depth=1 https://github.com/Muzammil-404/MAFIA.git`

- `cd MAFIA`

- `python MAFIA.py`

 

 

 

 ___This Tools is Free___</br>

 [![Whatsapp](https://img.shields.io/badge/Whatsapp-MAFIA-deepgreen?style=flat-square&logo=whatsapp)](https://wa.me/+923091649663)

 
